'use client';

import * as React from 'react';
import { Calendar, Plus } from 'lucide-react';
import { PageHeader } from '@/components/shared/page-header';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/features/auth/auth-context';
import { useAcademicSessions, useSetCurrentSession, useSetCurrentTerm } from '@/features/schools/hooks';
import { CreateSessionDialog } from '@/features/schools/create-session-dialog';
import { CreateTermDialog } from '@/features/schools/create-term-dialog';
import { ApiError } from '@/lib/api-client';
import { hasPermission } from '@/lib/permissions';
import { formatDate } from '@/lib/format-date';

export default function SettingsPage() {
  const { currentSchoolId, isOwner, permissionKeys } = useAuth();
  const { toast } = useToast();
  const sessionsQuery = useAcademicSessions(currentSchoolId);
  const setCurrentSessionMutation = useSetCurrentSession(currentSchoolId);
  const setCurrentTermMutation = useSetCurrentTerm(currentSchoolId);

  const [sessionDialogOpen, setSessionDialogOpen] = React.useState(false);
  const [termDialogFor, setTermDialogFor] = React.useState<{ id: string; name: string } | null>(null);

  // Settings changes are school-configuration actions — gate them behind
  // the same permission the backend checks for session/term mutation
  // routes (schools:update covers school + academic-structure endpoints).
  const canManage = hasPermission('schools:update', { isOwner, permissionKeys });

  async function handleSetCurrentSession(sessionId: string) {
    try {
      await setCurrentSessionMutation.mutateAsync(sessionId);
      toast({ title: 'Current session updated' });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: "Couldn't update current session",
        description: error instanceof ApiError ? error.message : 'Please try again.',
      });
    }
  }

  async function handleSetCurrentTerm(termId: string) {
    try {
      await setCurrentTermMutation.mutateAsync(termId);
      toast({ title: 'Current term updated' });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: "Couldn't update current term",
        description: error instanceof ApiError ? error.message : 'Please try again.',
      });
    }
  }

  return (
    <div className="space-y-6 pb-10">
      <PageHeader title="Settings" description="Manage your school's academic structure and configuration." />

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Academic Sessions</CardTitle>
            <p className="mt-1 text-[13px] text-navy-400">
              Sessions and terms drive every fee, payment, and report — set one up to get started.
            </p>
          </div>
          {canManage && (
            <Button size="sm" onClick={() => setSessionDialogOpen(true)}>
              <Plus className="h-4 w-4" />
              New Session
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {sessionsQuery.isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : sessionsQuery.isError ? (
            <ErrorState error={sessionsQuery.error} onRetry={() => sessionsQuery.refetch()} />
          ) : sessionsQuery.data && sessionsQuery.data.length > 0 ? (
            <div className="space-y-5">
              {sessionsQuery.data.map((session, idx) => (
                <div key={session.id}>
                  {idx > 0 && <Separator className="mb-5" />}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <p className="text-[14px] font-medium text-navy-900">{session.name}</p>
                      {session.isCurrent && <Badge variant="success">Current</Badge>}
                      {(session.startDate || session.endDate) && (
                        <span className="text-[12px] text-navy-400">
                          {formatDate(session.startDate)} – {formatDate(session.endDate)}
                        </span>
                      )}
                    </div>
                    {canManage && (
                      <div className="flex items-center gap-2">
                        {!session.isCurrent && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleSetCurrentSession(session.id)}
                            loading={setCurrentSessionMutation.isPending}
                          >
                            Set as current
                          </Button>
                        )}
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => setTermDialogFor({ id: session.id, name: session.name })}
                        >
                          <Plus className="h-3.5 w-3.5" />
                          Add Term
                        </Button>
                      </div>
                    )}
                  </div>

                  {session.terms && session.terms.length > 0 ? (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {session.terms.map((term) => (
                        <div
                          key={term.id}
                          className="flex items-center gap-2 rounded-md border border-border bg-surface-muted px-3 py-1.5"
                        >
                          <span className="text-[13px] text-navy-700">{term.name}</span>
                          {term.isCurrent ? (
                            <Badge variant="success">Current</Badge>
                          ) : (
                            canManage && (
                              <button
                                onClick={() => handleSetCurrentTerm(term.id)}
                                className="text-[11.5px] font-medium text-navy-400 hover:text-navy-900 hover:underline"
                              >
                                Set current
                              </button>
                            )
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="mt-2 text-[12.5px] text-navy-400">No terms yet — add one to enable fees and payments for this session.</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<Calendar className="h-5 w-5" />}
              title="No academic sessions yet"
              description="Create your first academic session (e.g. 2026/2027), then add terms to it. This is required before you can set fees or record payments."
              action={
                canManage ? (
                  <Button size="sm" onClick={() => setSessionDialogOpen(true)}>
                    <Plus className="h-4 w-4" />
                    Create Session
                  </Button>
                ) : undefined
              }
            />
          )}
        </CardContent>
      </Card>

      <CreateSessionDialog open={sessionDialogOpen} onOpenChange={setSessionDialogOpen} />
      {termDialogFor && (
        <CreateTermDialog
          open={Boolean(termDialogFor)}
          onOpenChange={(open) => !open && setTermDialogFor(null)}
          sessionId={termDialogFor.id}
          sessionName={termDialogFor.name}
        />
      )}
    </div>
  );
}