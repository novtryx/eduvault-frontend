import { z } from 'zod';

export const academicSessionSchema = z.object({
  name: z.string().min(4, 'e.g. "2026/2027"').max(20),
  startDate: z.string().optional().or(z.literal('')),
  endDate: z.string().optional().or(z.literal('')),
});
export type AcademicSessionFormValues = z.infer<typeof academicSessionSchema>;

export const termSchema = z.object({
  name: z.string().min(2, 'e.g. "First Term"').max(50),
  startDate: z.string().optional().or(z.literal('')),
  endDate: z.string().optional().or(z.literal('')),
});
export type TermFormValues = z.infer<typeof termSchema>;